MV RATHNAM LORRY TRANSPORT - SETUP

1) This is a starter website folder. It is not online until deployed.
2) Firebase Authentication must have Email/Password enabled.
3) IMPORTANT: Every authorised Firebase Authentication account needs a matching Firestore document:
   Collection: users
   Document ID: the account's Firebase Authentication UID (not Auto-ID)
   Fields:
     name: string (example "Admin")
     role: string ("admin" for owner, "member" for members)
   In Firebase Console > Authentication > Users, copy each user's UID.
   In Firestore > users, create a document using that exact UID.
4) Publish firestore.rules in Firebase Console > Firestore Database > Rules, then Publish.
5) Deploy the contents of this folder using Firebase Hosting. The Firebase CLI is the easiest route:
   - Install Node.js on a computer.
   - Run: npm install -g firebase-tools
   - Run: firebase login
   - In this folder run: firebase init hosting
   - Choose existing project: mvrathnam-lorry-transpor-293da
   - Public directory: .   (a dot)
   - Configure as single-page app: No
   - Do not overwrite index.html
   - Run: firebase deploy --only hosting
6) Your website URL will look like https://mvrathnam-lorry-transpor-293da.web.app

SECURITY NOTES
- Firebase web apiKey is designed to be present in browser code; it is not an admin password.
- Never share Firebase service-account JSON, passwords, or private keys.
- Do not use open/test Firestore rules for a live transport business.
- Members can add and view records. Only admin can edit/delete records with these rules.
- This starter does not yet include edit/delete buttons, reports, export, or user-management UI.
