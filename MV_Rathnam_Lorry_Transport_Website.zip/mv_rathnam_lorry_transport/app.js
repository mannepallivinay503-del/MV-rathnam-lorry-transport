// Firebase web configuration supplied by the project owner.
// Firebase apiKey is a public client identifier; protect data with Firestore Security Rules.
const firebaseConfig = {
  apiKey: "AIzaSyDdN3iWEtOwQP_lj7-TevDWtZ0Ry0bM0",
  authDomain: "mvrathnam-lorry-transpor-293da.firebaseapp.com",
  projectId: "mvrathnam-lorry-transpor-293da",
  storageBucket: "mvrathnam-lorry-transpor-293da.firebasestorage.app",
  messagingSenderId: "521384874291",
  appId: "1:521384874291:web:de4ee31f8ad4bf33dcae46",
  measurementId: "G-HSDK7RFYX1"
};

firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const db = firebase.firestore();
const $ = id => document.getElementById(id);
const today = new Date().toISOString().slice(0,10);
$("tripDate").value = today;
$("entryDate").value = today;

function showMessage(id, msg, ok=false){ const el=$(id); el.textContent=msg; el.style.color=ok?"#067647":"#b42318"; }
function updateAmount(){
  const weight = Number($("weight").value || 0);
  const rate = Number($("rate").value || 0);
  $("amount").value = weight && rate ? (weight*rate).toFixed(2) : "";
}
$("weight").addEventListener("input", updateAmount);
$("rate").addEventListener("input", updateAmount);

$("loginBtn").addEventListener("click", async ()=>{
  showMessage("loginMessage","");
  try { await auth.signInWithEmailAndPassword($("email").value.trim(), $("password").value); }
  catch(e){ showMessage("loginMessage", friendlyError(e)); }
});
$("logoutBtn").addEventListener("click", ()=>auth.signOut());

function friendlyError(e){
  if(e.code==="auth/invalid-credential") return "Email or password is incorrect.";
  if(e.code==="auth/too-many-requests") return "Too many attempts. Please try again later.";
  return e.message || "Something went wrong.";
}

auth.onAuthStateChanged(async user=>{
  if(!user){ $("loginCard").hidden=false; $("dashboard").hidden=true; return; }
  try{
    const profile = await db.collection("users").doc(user.uid).get();
    if(!profile.exists || !["admin","member"].includes(profile.data().role)){
      await auth.signOut();
      showMessage("loginMessage","Your account has no authorised user profile. Ask the admin to add your UID and role in Firestore.");
      return;
    }
    $("loginCard").hidden=true; $("dashboard").hidden=false;
    $("userInfo").textContent = `${profile.data().name || user.email} · ${profile.data().role}`;
    await loadTables();
  }catch(e){
    showMessage("loginMessage","Could not load user profile. Check Firestore rules and users document. "+e.message);
    await auth.signOut();
  }
});

$("saveTripBtn").addEventListener("click", async ()=>{
  const user=auth.currentUser;
  const weight=Number($("weight").value), rate=Number($("rate").value);
  if(!$("tripDate").value || !$("lorryNo").value.trim() || !weight || !rate){
    showMessage("tripMessage","Enter date, lorry number, weight and rate."); return;
  }
  try{
    await db.collection("trips").add({
      date:$("tripDate").value, lorryNo:$("lorryNo").value.trim(),
      lorryDriver:$("lorryDriver").value.trim(), tractorDriver:$("tractorDriver").value.trim(),
      material:$("material").value.trim(), weight, rate, amount:Number((weight*rate).toFixed(2)),
      notes:$("tripNotes").value.trim(), createdBy:user.uid, createdAt:firebase.firestore.FieldValue.serverTimestamp()
    });
    showMessage("tripMessage","Trip saved successfully.",true);
    ["lorryNo","lorryDriver","tractorDriver","material","weight","rate","amount","tripNotes"].forEach(id=>$(id).value="");
    await loadTables();
  }catch(e){showMessage("tripMessage","Save failed: "+e.message);}
});

$("saveEntryBtn").addEventListener("click", async ()=>{
  const amount=Number($("entryAmount").value);
  if(!amount || amount<=0 || !$("entryDate").value){showMessage("entryMessage","Enter a valid date and amount.");return;}
  try{
    await db.collection("entries").add({
      date:$("entryDate").value, type:$("entryType").value, amount,
      description:$("entryDescription").value.trim(), createdBy:auth.currentUser.uid,
      createdAt:firebase.firestore.FieldValue.serverTimestamp()
    });
    showMessage("entryMessage","Entry saved successfully.",true);
    $("entryAmount").value=""; $("entryDescription").value="";
    await loadTables();
  }catch(e){showMessage("entryMessage","Save failed: "+e.message);}
});

async function loadTables(){
  const [trips,entries]=await Promise.all([
    db.collection("trips").orderBy("createdAt","desc").limit(50).get(),
    db.collection("entries").orderBy("createdAt","desc").limit(50).get()
  ]);
  $("tripsBody").innerHTML="";
  trips.forEach(doc=>{
    const x=doc.data(); const tr=document.createElement("tr");
    [x.date,x.lorryNo,x.lorryDriver,x.tractorDriver,x.material,x.weight,`₹${Number(x.amount||0).toFixed(2)}`].forEach(v=>{const td=document.createElement("td");td.textContent=v??"";tr.appendChild(td);});
    $("tripsBody").appendChild(tr);
  });
  $("entriesBody").innerHTML="";
  entries.forEach(doc=>{
    const x=doc.data(); const tr=document.createElement("tr");
    [x.date,(x.type||"").toUpperCase(),x.description,`₹${Number(x.amount||0).toFixed(2)}`].forEach(v=>{const td=document.createElement("td");td.textContent=v??"";tr.appendChild(td);});
    $("entriesBody").appendChild(tr);
  });
}